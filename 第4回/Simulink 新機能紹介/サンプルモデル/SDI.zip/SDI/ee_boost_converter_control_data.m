%% Parameters for Boost Converter Voltage Control Example
% 
% This example shows how to control the output voltage of a boost 
% converter. To adjust the duty cycle, the Control subsystem
% uses a PI-based control algorithm. The input voltage is considered constant 
% throughout the simulation. A variable resistor provides the load for 
% the system. The total simulation time (t) is 0.25 seconds. At t = 0.15 
% seconds, the load changes.

% Copyright 2017-2018 The MathWorks, Inc.

%% System Parameters
Vin = 12;     % Input voltage [V]
L   = 4e-5;   % Inductance    [H]
C   = 6e-4;   % Capacitance   [F]
R   = 0.01;   % Capacitor effective series resistance [Ohm]

%% Control Parameters
Ts  = 5e-6; % Fundamental sample time            [s]
Tsc = 1e-4; % Sample time for inner control loop [s]

Kp  = 0.0547; % Controller proportional gain
Ki  = 8.8644; % Controller integrator gain speed