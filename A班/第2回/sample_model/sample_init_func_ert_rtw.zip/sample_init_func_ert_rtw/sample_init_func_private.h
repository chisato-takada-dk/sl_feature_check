/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * File: sample_init_func_private.h
 *
 * Code generated for Simulink model 'sample_init_func'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Wed Feb 19 11:48:20 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_sample_init_func_private_h_
#define RTW_HEADER_sample_init_func_private_h_
#include "rtwtypes.h"
#include "sample_init_func_types.h"
#endif                              /* RTW_HEADER_sample_init_func_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
