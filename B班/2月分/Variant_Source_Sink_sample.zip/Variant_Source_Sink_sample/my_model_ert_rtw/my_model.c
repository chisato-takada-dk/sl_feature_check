/*
 * File: my_model.c
 *
 * Code generated for Simulink model 'my_model'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Fri Feb 28 15:42:05 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "my_model.h"
#include "my_model_private.h"

/* External inputs (root inport signals with default storage) */
ExtU_my_model_T my_model_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_my_model_T my_model_Y;

/* Real-time model */
RT_MODEL_my_model_T my_model_M_;
RT_MODEL_my_model_T *const my_model_M = &my_model_M_;

/* Model step function */
void my_model_step(void)
{
  real_T rtb_VM_Conditional_Signal_Add_0;

  /* Outputs for Atomic SubSystem: '<Root>/Subsystem' */
  /* SignalConversion generated from: '<S1>/Variant Source' incorporates:
   *  Constant: '<S1>/Constant1'
   */
#if VARIANT_2

  my_model_Y.Out3 = 1.0;

#endif

  /* End of SignalConversion generated from: '<S1>/Variant Source' */

  /* Inport: '<S1>/In1' */
#if VARIANT_1

  /* Inport: '<Root>/In1' */
  my_model_Y.Out3 = my_model_U.In1;

#endif

  /* End of Inport: '<S1>/In1' */

  /* SignalConversion generated from: '<S1>/Add' */
#if VARIANT_2

  rtb_VM_Conditional_Signal_Add_0 = my_model_Y.Out3;

#else

  /* SignalConversion generated from: '<S1>/Add' */
  rtb_VM_Conditional_Signal_Add_0 = 0.0;

#endif

  /* End of SignalConversion generated from: '<S1>/Add' */

  /* Outport: '<Root>/Out1' incorporates:
   *  Inport: '<Root>/In2'
   *  Sum: '<S1>/Add'
   */
  my_model_Y.Out1 = rtb_VM_Conditional_Signal_Add_0 + my_model_U.In2;

  /* End of Outputs for SubSystem: '<Root>/Subsystem' */

  /* Outport: '<Root>/Out2' */
#if VARIANT_1

  my_model_Y.Out2 = my_model_Y.Out3;

#endif

  /* End of Outport: '<Root>/Out2' */
}

/* Model initialize function */
void my_model_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void my_model_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
