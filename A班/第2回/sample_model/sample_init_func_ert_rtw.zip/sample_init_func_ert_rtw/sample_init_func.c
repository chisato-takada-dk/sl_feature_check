/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * File: sample_init_func.c
 *
 * Code generated for Simulink model 'sample_init_func'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Wed Feb 19 11:48:20 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sample_init_func.h"
#include "sample_init_func_private.h"

/* External inputs (root inport signals with default storage) */
ExtU_sample_init_func_T sample_init_func_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_sample_init_func_T sample_init_func_Y;

/* Real-time model */
RT_MODEL_sample_init_func_T sample_init_func_M_;
RT_MODEL_sample_init_func_T *const sample_init_func_M = &sample_init_func_M_;

/* Model step function */
void In4(void)
{
  /* RootInportFunctionCallGenerator generated from: '<Root>/In4' incorporates:
   *  SubSystem: '<Root>/Function-Call Subsystem'
   */
  /* Outport: '<Root>/Out1' incorporates:
   *  Inport: '<Root>/In2'
   *  Inport: '<Root>/In3'
   *  Product: '<S1>/Product'
   */
  sample_init_func_Y.Out1 = (uint16_T)((uint32_T)sample_init_func_U.In2 *
    sample_init_func_U.In3);

  /* End of Outputs for RootInportFunctionCallGenerator generated from: '<Root>/In4' */
}

/* Model initialize function */
void sample_init_func_initialize(void)
{
  /* SystemInitialize for Atomic SubSystem: '<Root>/Initialize Function' */
#if Variant

  /* Outport: '<Root>/Out2' incorporates:
   *  Inport: '<Root>/In1'
   *  Inport: '<S2>/In1'
   */
  sample_init_func_Y.Out2 = sample_init_func_U.In1;

  /* Outputs for Atomic SubSystem: '<S2>/Variant Subsystem' */
#if VariantSub

  /* SubSystem: '<S3>/Subsystem'
   */
#elif VariantSub2

  /* SubSystem: '<S3>/Subsystem1'
   */
#endif

  /* End of Outputs for SubSystem: '<S2>/Variant Subsystem' */

  /* Outport: '<Root>/Out1' incorporates:
   *  Constant: '<S2>/Constant1'
   */
  sample_init_func_Y.Out1 = 10U;

#endif

  /* End of SystemInitialize for SubSystem: '<Root>/Initialize Function' */
}

/* Model terminate function */
void sample_init_func_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
