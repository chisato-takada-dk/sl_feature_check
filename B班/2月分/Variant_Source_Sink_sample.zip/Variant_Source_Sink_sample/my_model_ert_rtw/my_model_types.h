/*
 * File: my_model_types.h
 *
 * Code generated for Simulink model 'my_model'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Fri Feb 28 15:42:05 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_my_model_types_h_
#define RTW_HEADER_my_model_types_h_

/* Model Code Variants */
/**
 * You can use either of the following to alter the value of "normal" variant
 * control variables:
 *
 *  1. -DVC_VARIABLE1=VALUE1 -DVC_VARIABLE2=VALUE2, etc.
 *  2. -DUSE_VARIANT_DEFINES_HEADER="header.h" and within header.h you
 *      specify "#define VC_VARIABLE VALUE1", etc.
 *
 * Variant control variables are the independent variables of variant control
 * expressions specified in a variant block. For example, a Variant Source block
 * may contain "V==1" and V is the variant control variable of this
 * expression. A normal variant control variable is a plain MATLAB variable,
 * i.e. not a Simulink.Parameter.  The default define for a normal variant
 * control variable is the value specified in MATLAB at time of code generation.
 *
 * Alternatively, you can use Simulink.Parameter's as variant control variables to
 * explicitly specify code generation behavior.
 */
#ifdef USE_VARIANT_DEFINES_HEADER
#define VARIANT_DEFINES_HEADER_STR(h)  #h
#define VARIANT_DEFINES_HEADER(h)      VARIANT_DEFINES_HEADER_STR(h)
#include VARIANT_DEFINES_HEADER(USE_VARIANT_DEFINES_HEADER)
#endif                                 /* USE_VARIANT_DEFINES_HEADER */

/*
 * Validate the variant control variables are consistent with the model requirements
 */
#ifndef CTRL_MODE
#define CTRL_MODE                      2
#endif

#ifndef VARIANT_1
#define VARIANT_1                      (CTRL_MODE == 1)
#endif

#ifndef VARIANT_2
#define VARIANT_2                      (CTRL_MODE == 2)
#endif

#if ((VARIANT_1) ? 1 : 0) + ((VARIANT_2) ? 1 : 0) != 1
#error Exactly one variant for 'my_model/Subsystem/Variant Sink' should be active
#endif

#if ((VARIANT_1) ? 1 : 0) + ((VARIANT_2) ? 1 : 0) != 1
#error Exactly one variant for 'my_model/Subsystem/Variant Source' should be active
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_my_model_T RT_MODEL_my_model_T;

#endif                                 /* RTW_HEADER_my_model_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
