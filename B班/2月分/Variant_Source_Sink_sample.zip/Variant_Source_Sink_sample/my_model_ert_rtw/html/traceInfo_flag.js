function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["my_model.c:74c53"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["my_model.c:40"]=1;
    this.lineTraceFlag["my_model.c:47"]=1;
    this.lineTraceFlag["my_model.c:50"]=1;
    this.lineTraceFlag["my_model.c:74"]=1;
    this.lineTraceFlag["my_model.c:79"]=1;
    this.lineTraceFlag["my_model.c:81"]=1;
    this.lineTraceFlag["my_model.h:39"]=1;
    this.lineTraceFlag["my_model.h:44"]=1;
    this.lineTraceFlag["my_model.h:49"]=1;
    this.lineTraceFlag["my_model.h:53"]=1;
    this.lineTraceFlag["my_model.h:58"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
