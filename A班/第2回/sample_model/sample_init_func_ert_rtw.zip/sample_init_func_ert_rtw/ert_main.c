/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * File: ert_main.c
 *
 * Code generated for Simulink model 'sample_init_func'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Wed Feb 19 11:48:20 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include <stdio.h>              /* This ert_main.c example uses printf/fflush */
#include "sample_init_func.h"          /* Model's header file */
#include "rtwtypes.h"
#include "stddef.h"

/*
 * Example use case for call to exported function:
 * In4
 */
extern void sample_usage_In4(void);
void sample_usage_In4(void)
{
  /*
   * Set task inputs here:
   */

  /*
   * Call to exported function
   */
  In4();

  /*
   * Read function outputs here
   */
}

/*
 * The example "main" function illustrates what is required by your
 * application code to initialize, execute, and terminate the generated code.
 * Attaching exported functions to a real-time clock is target specific.
 * This example illustrates how you do this relative to initializing the model.
 */
int_T main(int_T argc, const char *argv[])
{
  /* Unused arguments */
  (void)(argc);
  (void)(argv);

  /* Initialize model */
  sample_init_func_initialize();

  /* First time initialization of system output variables.
   * Constant and invariant outputs will not be updated
   * after this step.
   */
  while (rtmGetErrorStatus(sample_init_func_M) == (NULL)) {
    /*  Perform application tasks here. */
  }

  /* Terminate model */
  sample_init_func_terminate();
  return 0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
