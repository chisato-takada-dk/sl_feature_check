function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["sample_init_func.c:43c73"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["sample_init_func.c:43"]=1;
    this.lineTraceFlag["sample_init_func.c:44"]=1;
    this.lineTraceFlag["sample_init_func.c:53"]=1;
    this.lineTraceFlag["sample_init_func.c:59"]=1;
    this.lineTraceFlag["sample_init_func.c:62"]=1;
    this.lineTraceFlag["sample_init_func.c:66"]=1;
    this.lineTraceFlag["sample_init_func.c:77"]=1;
    this.lineTraceFlag["sample_init_func.h:43"]=1;
    this.lineTraceFlag["sample_init_func.h:48"]=1;
    this.lineTraceFlag["sample_init_func.h:49"]=1;
    this.lineTraceFlag["sample_init_func.h:54"]=1;
    this.lineTraceFlag["sample_init_func.h:58"]=1;
    this.lineTraceFlag["sample_init_func.h:65"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
