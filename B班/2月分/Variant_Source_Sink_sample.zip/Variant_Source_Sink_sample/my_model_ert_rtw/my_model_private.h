/*
 * File: my_model_private.h
 *
 * Code generated for Simulink model 'my_model'.
 *
 * Model version                  : 1.18
 * Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
 * C/C++ source code generated on : Fri Feb 28 15:42:05 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_my_model_private_h_
#define RTW_HEADER_my_model_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_my_model_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
